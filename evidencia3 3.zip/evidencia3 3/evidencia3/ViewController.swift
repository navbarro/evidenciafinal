//
//  ViewController.swift
//  evidencia3
//
//  Created by Juan Miguel Flores on 29/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

